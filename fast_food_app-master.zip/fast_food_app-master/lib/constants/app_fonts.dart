import 'package:fast_food_app/constants/app_imports.dart';

class AppFonts {
  static TextStyle font20White = TextStyle(
    fontSize: 20.sp,
    color: AppColors.whiteColor,
  );
}
